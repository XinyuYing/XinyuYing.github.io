#!/usr/bin/env python3
"""Print a local stdio-client example. Does not edit host configuration."""
import argparse,json,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2]);p.add_argument('--python',default=sys.executable)
a=p.parse_args();root=a.root.resolve()
if not (root/'MCP/local_project_server.py').is_file():p.error('MCP server not found in selected kit')
print(json.dumps({'mcpServers':{'product-website-kit':{'command':a.python,'args':[str(root/'MCP/local_project_server.py'),'--root',str(root)]}}},ensure_ascii=False,indent=2))
