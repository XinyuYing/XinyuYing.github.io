#!/usr/bin/env python3
"""Create plain Chinese/English Word documents; requires python-docx."""
from pathlib import Path
import re
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

def font(run, bold=False):
    run.font.name='Times New Roman';run.font.size=Pt(12);run.font.bold=bold;run.font.color.rgb=RGBColor(0,0,0)
    props=run._element.get_or_add_rPr();fonts=props.rFonts
    if fonts is None:fonts=OxmlElement('w:rFonts');props.insert(0,fonts)
    for key,value in [('ascii','Times New Roman'),('hAnsi','Times New Roman'),('eastAsia','Songti SC'),('cs','Times New Roman')]:
        fonts.set(qn('w:'+key),value)

def inline(p,text,bold=False,links=True):
    text=text.replace('**','').replace('`','')
    if not links:font(p.add_run(text),bold);return
    pos=0
    for m in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)',text):
        if m.start()>pos:font(p.add_run(text[pos:m.start()]),bold)
        label,target=m.groups()
        h=OxmlElement('w:hyperlink')
        if target.startswith('#'):h.set(qn('w:anchor'),target[1:])
        else:h.set(qn('r:id'),p.part.relate_to(target,RT.HYPERLINK,is_external=True))
        r=p.add_run(label);font(r,bold);h.append(r._r);p._p.append(h);pos=m.end()
    if pos<len(text):font(p.add_run(text[pos:]),bold)

def add_para(doc,text,style=None,code=False):
    p=doc.add_paragraph(style=style);pf=p.paragraph_format
    pf.space_before=Pt(0);pf.space_after=Pt(5 if not code else 1);pf.line_spacing=Pt(14.5 if code else 17)
    grid=OxmlElement('w:snapToGrid');grid.set(qn('w:val'),'0');p._p.get_or_add_pPr().append(grid)
    pf.widow_control=True
    if code:pf.left_indent=Cm(.45);pf.right_indent=Cm(.15)
    heading=bool(style and (style.startswith('Heading') or style=='Title'))
    if heading:
        pf.space_before=Pt(8 if style!='Title' else 0);pf.space_after=Pt(7);pf.keep_with_next=True
        text=re.sub(r'[^\w\s\u3400-\u9fff]',' ',text);text=re.sub(r'\s+',' ',text).strip()
    inline(p,text,heading,not code)
    return p

def table(doc,rows):
    data=[[x.strip() for x in row.strip().strip('|').split('|')] for row in rows]
    data=[r for r in data if not all(re.fullmatch(r':?-+:?',c) for c in r)]
    n=len(data[0]);t=doc.add_table(rows=0,cols=n);t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    widths={2:[5.4,10.6],3:[3.4,6.4,6.2],4:[2.3,4.6,4.6,4.5],5:[1.55,3.6,3.35,5.0,2.5]}.get(n,[16/n]*n)
    if n==5 and data[0][0]=='能力':widths=[2.4,1.8,3.8,4.8,3.2]
    elif n==4 and data[0][:2]==['维度','分值']:widths=[3.8,1.4,6.0,4.8]
    for col,width in zip(t.columns,widths):col.width=Cm(width)
    borders=OxmlElement('w:tblBorders')
    for edge in ['top','left','bottom','right','insideH','insideV']:
        e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    t._tbl.tblPr.append(borders)
    for idx,row in enumerate(data):
        if len(row)!=n:raise ValueError('Unequal table column count')
        cells=t.add_row().cells;trPr=t.rows[-1]._tr.get_or_add_trPr();trPr.append(OxmlElement('w:cantSplit'))
        if idx==0:trPr.append(OxmlElement('w:tblHeader'))
        for c,text,width in zip(cells,row,widths):
            c.width=Cm(width);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p=c.paragraphs[0];p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3);p.paragraph_format.line_spacing=Pt(15)
            inline(p,text)
            margins=OxmlElement('w:tcMar')
            for side,val in [('top','65'),('bottom','65'),('left','80'),('right','80')]:
                e=OxmlElement('w:'+side);e.set(qn('w:w'),val);e.set(qn('w:type'),'dxa');margins.append(e)
            c._tc.get_or_add_tcPr().append(margins)
    p=doc.add_paragraph();p.paragraph_format.space_after=Pt(1);font(p.add_run(''))

def build_document(source,out,title=None):
    out=Path(out);doc=Document();sec=doc.sections[0]
    sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.top_margin=Cm(1.9);sec.bottom_margin=Cm(1.8);sec.left_margin=Cm(2.5);sec.right_margin=Cm(2.5)
    for x in list(sec._sectPr.iter(qn('w:docGrid'))):x.getparent().remove(x)
    for name in ['Normal','Title','Heading 1','Heading 2','Heading 3']:
        s=doc.styles[name];s.font.name='Times New Roman';s.font.size=Pt(12);s.font.color.rgb=RGBColor(0,0,0);s.font.bold=name!='Normal'
        s.element.rPr.rFonts.set(qn('w:eastAsia'),'Songti SC')
        for attr in list(s.element.rPr.rFonts.attrib):
            if 'theme' in attr.lower():del s.element.rPr.rFonts.attrib[attr]
    for x in list(doc.styles.element.iter(qn('w:pBdr'))):x.getparent().remove(x)
    footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=footer.add_run();font(r)
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');r._r.addnext(field)
    lines=source.splitlines();i=0;had_title=False
    if not any(s.startswith('# ') for s in lines):
        add_para(doc,title or out.stem,'Title');had_title=True
    while i<len(lines):
        line=lines[i]
        if not line.strip() or line.strip()=='---':i+=1;continue
        if line=='<!-- page -->':
            j=i+1
            while j<len(lines) and not lines[j].strip():j+=1
            if j<len(lines) and lines[j].startswith('## '):
                p=add_para(doc,lines[j][3:],'Heading 1');p.paragraph_format.page_break_before=True;i=j+1;continue
        if line.startswith('```'):
            i+=1
            while i<len(lines) and not lines[i].startswith('```'):add_para(doc,lines[i],code=True);i+=1
            i+=1;continue
        if line.startswith('|'):
            group=[]
            while i<len(lines) and lines[i].startswith('|'):group.append(lines[i]);i+=1
            table(doc,group);continue
        if line.startswith('# '):
            add_para(doc,line[2:],'Title' if not had_title else 'Heading 1');had_title=True
        elif line.startswith('## '):add_para(doc,line[3:],'Heading 1')
        elif line.startswith('### '):add_para(doc,line[4:],'Heading 2')
        elif line.startswith('#### '):add_para(doc,line[5:],'Heading 3')
        elif line.startswith('- '):add_para(doc,'• '+line[2:].replace('[ ]','□'))
        else:add_para(doc,line)
        i+=1
    heading=next((s[2:] for s in lines if s.startswith('# ')),title or out.stem)
    doc.core_properties.title=re.sub(r'[^\w\s\u3400-\u9fff]',' ',heading)
    doc.core_properties.author='课程教学资料';doc.core_properties.comments=''
    out.parent.mkdir(parents=True,exist_ok=True);doc.save(out)
    return out
