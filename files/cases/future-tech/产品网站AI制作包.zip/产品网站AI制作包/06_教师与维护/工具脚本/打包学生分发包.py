#!/usr/bin/env python3
"""Package only declared teaching files; exclude unlisted student work."""
from pathlib import Path
import hashlib,importlib.util,json,zipfile
ROOT=Path(__file__).resolve().parents[2]
def module(name,file):
    spec=importlib.util.spec_from_file_location(name,Path(__file__).parent/file)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def build():
    module('assemble','生成AI执行手册.py').build()
    v=module('verify','检查制作包.py')
    result=v.verify()
    if result['status']!='passed':raise ValueError(json.dumps(result,ensure_ascii=False))
    spec=v.distribution(ROOT)
    for rel,h in spec.get('student_baselines',{}).items():
        if hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=h:
            raise ValueError('Student input/progress has changed; use a clean teaching copy: '+rel)
    files=[ROOT/p for p in spec['files']]
    manifest={'version':'1.1','directories':spec['directories'],'files':[{'path':str(f.relative_to(ROOT)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]}
    (ROOT/'文件清单.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    archive=ROOT.parent/(ROOT.name+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for rel in spec['directories']:z.writestr(ROOT.name+'/'+rel.rstrip('/')+'/',b'')
        for f in files+[ROOT/'文件清单.json']:z.write(f,str(Path(ROOT.name)/f.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        bad=z.testzip()
        if bad:raise ValueError('Corrupt ZIP member: '+bad)
        for item in manifest['files']:
            data=z.read(str(Path(ROOT.name)/item['path']))
            if hashlib.sha256(data).hexdigest()!=item['sha256']:raise ValueError('ZIP hash mismatch: '+item['path'])
    return {'archive':archive.name,'bytes':archive.stat().st_size,'files':len(files)+1,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'status':'verified'}
if __name__=='__main__':print(json.dumps(build(),ensure_ascii=False,indent=2))

