#!/usr/bin/env python3
"""Rebuild only the chat TXT manual. Never overwrite student Word files."""
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from 文档读取 import read_document
def clean(s):return re.sub(r'\[([^\]]+)\]\((?!https?://|#)[^)]+\)',r'\1',s)
def build():
    parts=['产品网站AI制作执行手册\n\n学生提供五方面想法，AI生成五份Prompt Word并重新读取，再制作和检查网站。\n请先看下一节的目录及启动指令。']
    files=['文件导航与命名规则.docx','01_学生想法与启动/02_开始制作_发给AI.txt','01_学生想法与启动/01_五个想法_发给AI.txt','06_教师与维护/02_角色与步骤总览.docx','04_检查修改与提交/02_网站验收标准.docx','Agents/00_角色分工说明.docx']
    for f in files:parts.append(clean(read_document(ROOT/f)))
    for f in sorted((ROOT/'Agents').glob('[0-9][0-9]_*.md')):parts.append(clean(read_document(f)))
    for b in json.loads((ROOT/'06_教师与维护/工具脚本/步骤索引.json').read_text()):
        for name in ['SKILL.md','01_调用提示词.md','02_输出要求.md','04_检查与返工.md']:
            s=read_document(ROOT/'Skills'/b['folder']/name)
            if name=='SKILL.md':s=re.sub(r'^---\n.*?\n---\n','',s,flags=re.S)
            parts.append(clean(s))
    parts.append(clean(read_document(ROOT/'01_学生想法与启动/04_上传与工具说明.docx')))
    path=ROOT/'01_学生想法与启动/03_AI执行手册_无法读压缩包时上传.txt'
    path.write_text('\n\n---\n\n'.join(parts)+'\n',encoding='utf-8')
    return {'file':str(path.relative_to(ROOT)),'characters':len(path.read_text())}
if __name__=='__main__':print(json.dumps(build(),ensure_ascii=False,indent=2))
