#!/usr/bin/env python3
"""Exercise real five-Word creation, revision, rollback, and MCP readback."""
import copy, hashlib, importlib.util, json, subprocess, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("prompt_writer", ROOT / "06_教师与维护/工具脚本/生成五份Prompt.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
EXAMPLE = json.loads((ROOT / "05_FutureTech完整示例/07_Prompt生成记录/01_结构化内容.json").read_text(encoding="utf-8"))

def snapshot(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (root / "02_AI生成的Prompt").glob("*.docx")}

class PromptFlowTests(unittest.TestCase):
    def test_actual_word_and_mcp_readback(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            receipt = m.generate(EXAMPLE, root)
            self.assertEqual(len(receipt["documents"]), 5)
            for folder in ("Agents", "Skills"): (root / folder).mkdir()
            messages = [
                {"jsonrpc": "2.0", "id": 1, "method": "initialize",
                 "params": {"protocolVersion": "2025-11-25", "capabilities": {}, "clientInfo": {"name": "prompt-test", "version": "1"}}},
                {"jsonrpc": "2.0", "method": "notifications/initialized"}
            ]
            for i, item in enumerate(receipt["documents"]):
                messages.append({"jsonrpc": "2.0", "id": i+2, "method": "tools/call",
                                 "params": {"name": "read_project_text", "arguments": {"path": item["path"]}}})
            result = subprocess.run([sys.executable, str(ROOT / "MCP/local_project_server.py"), "--root", str(root)],
                                    input="\n".join(json.dumps(x, ensure_ascii=False) for x in messages)+"\n",
                                    text=True, encoding="utf-8", capture_output=True, timeout=15)
            self.assertEqual(result.returncode, 0, result.stderr)
            replies = [json.loads(line) for line in result.stdout.splitlines()][1:]
            self.assertEqual(len(replies), 5)
            for source, reply in zip(EXAMPLE["documents"], replies):
                self.assertFalse(reply["result"]["isError"])
                text = json.loads(reply["result"]["content"][0]["text"])["content"]
                self.assertIn(source["idea"], text)
                for paragraph in source["prompt"].values(): self.assertIn(paragraph, text)
                self.assertIn(EXAMPLE["version"], text)

    def test_revision_keeps_original_and_new_story(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); m.generate(EXAMPLE, root)
            old = (root / "02_AI生成的Prompt/03_故事线_Prompt.docx").read_bytes()
            update = copy.deepcopy(EXAMPLE); update["version"] = "FT-PROMPT-2"
            update["documents"][2]["idea"] += "训练缩短，突出聚会后去露台。"
            update["documents"][2]["prompt"]["网页要求"] += "缩短训练区，把聚会后的改道作为重点。"
            result = m.generate(update, root)
            history = root / result["history"]
            self.assertEqual((history / "02_AI生成的Prompt/03_故事线_Prompt.docx").read_bytes(), old)
            self.assertIn("训练缩短，突出聚会后去露台", m.read_document(root / "02_AI生成的Prompt/03_故事线_Prompt.docx"))
            for item in result["documents"]:
                self.assertIn("FT-PROMPT-2", m.read_document(root / item["path"]))
            self.assertIn(EXAMPLE["documents"][3]["prompt"]["配置与价格"], m.read_document(root / "02_AI生成的Prompt/04_价格配置_Prompt.docx"))

    def test_invalid_sets_never_replace_current_words(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); m.generate(EXAMPLE, root); before = snapshot(root)
            candidates = []
            data = copy.deepcopy(EXAMPLE); data["documents"].pop(); candidates.append(data)
            data = copy.deepcopy(EXAMPLE); data["documents"][1]["id"] = "01"; candidates.append(data)
            data = copy.deepcopy(EXAMPLE); del data["documents"][2]["prompt"]["网页要求"]; candidates.append(data)
            data = copy.deepcopy(EXAMPLE); data["documents"][0]["idea"] = "待填写"; candidates.append(data)
            for data in candidates:
                with self.assertRaises(ValueError): m.generate(data, root)
                self.assertEqual(snapshot(root), before)

    def test_failed_commit_restores_complete_previous_set(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); m.generate(EXAMPLE, root); before = snapshot(root)
            previous_receipt = (root / "03_AI生成的网站/05_Prompt版本记录/生成与回读记录.json").read_bytes()
            original = m.os.replace; calls = []
            def fail_third(src, dest):
                calls.append(str(dest))
                if len(calls) == 3: raise OSError("Simulated interrupted save")
                return original(src, dest)
            update = copy.deepcopy(EXAMPLE); update["version"] = "interrupted-v2"
            with patch.object(m.os, "replace", side_effect=fail_third):
                with self.assertRaises(OSError): m.generate(update, root)
            self.assertEqual(snapshot(root), before)
            self.assertEqual((root / "03_AI生成的网站/05_Prompt版本记录/生成与回读记录.json").read_bytes(), previous_receipt)

if __name__ == "__main__": unittest.main(verbosity=2)

