#!/usr/bin/env python3
"""Validate Word/AI documents, references and distribution hygiene."""
from pathlib import Path
import json,re,sys
from urllib.parse import unquote
from zipfile import ZipFile
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'06_教师与维护/工具脚本'))
from 文档读取 import read_document
SKIP={'.git','node_modules','__pycache__','.venv','.DS_Store'}
TEXT={'.md','.txt','.json','.html','.css','.js','.ts','.tsx','.py','.toml','.docx'}
def distribution(root):
    spec=json.loads((root/'06_教师与维护/工具脚本/分发文件与空目录.json').read_text(encoding='utf-8'))
    for rel in spec['files']+spec['directories']:
        p=Path(rel)
        if p.is_absolute() or '..' in p.parts or any(x.startswith('.') or x.startswith('~$') for x in p.parts):raise ValueError('Unsafe distribution path: '+rel)
        if not(root/p).resolve().is_relative_to(root.resolve()):raise ValueError('Outside distribution: '+rel)
    return spec
def verify(root=ROOT):
    errors=[];spec=distribution(root);files=[root/p for p in spec['files']]
    required=['00_教学指南.docx','文件导航与命名规则.docx','AGENTS.md','01_学生想法与启动/02_开始制作_发给AI.txt','06_教师与维护/02_角色与步骤总览.docx','01_学生想法与启动/04_上传与工具说明.docx','04_检查修改与提交/02_网站验收标准.docx','MCP/local_project_server.py','01_学生想法与启动/03_AI执行手册_无法读压缩包时上传.txt','05_FutureTech完整示例/03_网站预览/index.html']+spec['files']
    for rel in spec['directories']:
        if not(root/rel).is_dir():errors.append('Missing directory: '+rel)
    required+=json.loads((root/'06_教师与维护/工具脚本/Word文档清单.json').read_text(encoding='utf-8'))
    for rel in required:
        if not(root/rel).is_file():errors.append('Missing required file: '+rel)
    blocks=json.loads((root/'06_教师与维护/工具脚本/步骤索引.json').read_text(encoding='utf-8'))
    if len(blocks)!=9:errors.append('Expected B0-B8')
    for b in blocks:
        folder=root/'Skills'/b['folder']
        for name in ['SKILL.md','01_调用提示词.md','02_输出要求.md','03_完成示例.md','04_检查与返工.md']:
            p=folder/name
            if not p.is_file() or p.stat().st_size<150:errors.append('Missing/empty contract: '+str(p.relative_to(root)))
        if (folder/'SKILL.md').is_file():
            text=(folder/'SKILL.md').read_text(encoding='utf-8')
            if not text.startswith('---\nname: '+b['folder']+'\n'):errors.append('Invalid skill name: '+b['folder'])
            if 'description: ' not in text:errors.append('Skill description missing: '+b['folder'])
            if '[TODO:' in text:errors.append('Unfinished skill: '+b['folder'])
    links=0;docx=0
    for f in files:
        rel=f.relative_to(root)
        if any(x.startswith('.') for x in rel.parts):errors.append('Hidden file in distribution: '+str(rel))
        if f.suffix not in TEXT:continue
        try:text=read_document(f)
        except (ValueError,UnicodeError,OSError) as e:errors.append('Unreadable document: '+str(rel)+': '+str(e));continue
        for term in ['/Users/'+'yingxinyu','appgprj'+'_','appgdep'+'_','git.chatgpt-team'+'.site','Bearer '+'eyJ']:
            if term in text:errors.append('Personal source binding found: '+str(rel))
        if f.suffix=='.md':
            allowed=f.name=='AGENTS.md' or (f.parent.name=='Agents' and f.name[:2].isdigit()) or f.parent.parent.name=='Skills'
            if not allowed:errors.append('Human-readable Markdown remains: '+str(rel))
        if f.suffix in {'.md','.docx'}:
            if f.suffix=='.docx':docx+=1
            for _,url in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',text):
                if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',url) or url.startswith('#'):continue
                url=unquote(url.split('#')[0].split('?')[0].strip('<>'));links+=1
                if not(f.parent/url).exists():errors.append('Broken reference: '+str(rel)+' -> '+url)
        if f.suffix=='.json':
            try:json.loads(text)
            except json.JSONDecodeError:errors.append('Invalid JSON: '+str(rel))
    web=root/'05_FutureTech完整示例/03_网站预览'
    html=(web/'index.html').read_text(encoding='utf-8') if web.exists() else ''
    for url in re.findall(r'(?:src|href)="(/[^"?#]+)',html):
        if not(web/url.lstrip('/')).is_file():errors.append('Missing web asset: '+url)
    if (root/'05_FutureTech完整示例/04_网站源码/.openai').exists():errors.append('Original hosting binding must not ship')
    return {'status':'passed' if not errors else 'failed','files':len(files),'word_documents':docx,'skills':len(blocks),'agents':len(list((root/'Agents').glob('[0-9][0-9]_*.md'))),'relative_links_checked':links,'errors':errors,'scope':'File, document-reading and reference checks; visual QA is separate.'}
if __name__=='__main__':
    result=verify();print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if result['status']=='passed' else 1)
