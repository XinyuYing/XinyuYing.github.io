#!/usr/bin/env python3
"""Check the authoritative Word guide without overwriting user edits."""
from pathlib import Path
from 文档读取 import read_document
ROOT=Path(__file__).resolve().parents[2]
def build():
    path=ROOT/'00_教学指南.docx'
    content=read_document(path)
    required=['一 流程','从五个角度提供想法','AI怎样把想法变成网站','想改网页时从哪个想法改起','检查网页并填写记录']
    missing=[text for text in required if text not in content]
    if missing:raise ValueError('Guide content is incomplete: '+', '.join(missing))
    print('Word讲义可读取；直接在Word中编辑，修改后检查不超过3页。')
    return path
if __name__=='__main__':build()
