#!/usr/bin/env python3
"""Exercise actual JSON-RPC stdin/stdout and read-only path boundaries."""
import importlib.util,json,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
SERVER=ROOT/'MCP/local_project_server.py'
spec=importlib.util.spec_from_file_location('kit_mcp',SERVER);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def rpc(messages,root=ROOT):
    raw='\n'.join(x if isinstance(x,str) else json.dumps(x,ensure_ascii=False) for x in messages)+'\n'
    run=subprocess.run([sys.executable,str(SERVER),'--root',str(root)],input=raw,capture_output=True,text=True,encoding='utf-8',timeout=10)
    if run.returncode:raise AssertionError(run.stderr)
    return [json.loads(x) for x in run.stdout.splitlines()]
def req(id,method,params=None):return {'jsonrpc':'2.0','id':id,'method':method,'params':params or {}}
def init():return [req(1,'initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'kit-selftest','version':'1'}}),{'jsonrpc':'2.0','method':'notifications/initialized'}]

class KitMCPTests(unittest.TestCase):
    def test_real_protocol_and_tools(self):
        out=rpc(init()+[req(2,'tools/list'),req(3,'tools/call',{'name':'list_project_files','arguments':{}})])
        self.assertEqual(len(out),3);self.assertEqual(out[0]['result']['protocolVersion'],'2025-11-25')
        self.assertEqual(len(out[1]['result']['tools']),3)
        payload=json.loads(out[2]['result']['content'][0]['text'])
        self.assertIn('02_AI生成的Prompt/03_故事线_Prompt.docx',payload['files'])
    def test_exact_segmented_read(self):
        path='02_AI生成的Prompt/03_故事线_Prompt.docx'
        out=rpc(init()+[req(2,'tools/call',{'name':'read_project_text','arguments':{'path':path,'start':3,'limit':20}})])
        data=json.loads(out[-1]['result']['content'][0]['text'])
        self.assertEqual(data['content'],m.read_document(ROOT/path)[3:23]);self.assertEqual(data['next_start'],23)
    def test_word_paragraphs_and_tables(self):
        out=rpc(init()+[req(2,'tools/call',{'name':'read_project_text','arguments':{'path':'02_AI生成的Prompt/04_价格配置_Prompt.docx'}})])
        result=out[-1]['result'];self.assertFalse(result['isError'])
        content=json.loads(result['content'][0]['text'])['content']
        self.assertIn('价格与单位',content);self.assertIn('P01',content);self.assertIn('默认本地交付',content)
    def test_all_block_contracts(self):
        messages=init()+[req(i+2,'tools/call',{'name':'get_block_prompt','arguments':{'block':'B'+str(i)}}) for i in range(9)]
        for i,out in enumerate(rpc(messages)[1:]):
            data=json.loads(out['result']['content'][0]['text']);self.assertEqual(data['block'],'B'+str(i));self.assertEqual(len(data['documents']),4)
            self.assertTrue(all(d['next_start'] is None for d in data['documents']))
    def test_path_and_argument_rejections(self):
        attempts=[{'path':'../README.md'},{'path':'/etc/passwd'},{'path':'.env'},{'path':'02_AI生成的Prompt/../README_从这里开始.md'},{'path':'02_AI生成的Prompt/03_人工故事线.md','limit':0},{'path':'02_AI生成的Prompt/03_人工故事线.md','start':True},{'path':'02_AI生成的Prompt/03_人工故事线.md','extra':1}]
        out=rpc(init()+[req(i+2,'tools/call',{'name':'read_project_text','arguments':a}) for i,a in enumerate(attempts)])
        self.assertTrue(all(x['result']['isError'] for x in out[1:]))
    def test_symlink_cannot_escape_root(self):
        with tempfile.TemporaryDirectory() as d:
            outer=Path(d);root=outer/'kit';root.mkdir();(root/'02_AI生成的Prompt').mkdir();outside=outer/'outside.md';outside.write_text('private outside')
            (root/'02_AI生成的Prompt/link.md').symlink_to(outside)
            with self.assertRaises(ValueError):m.read_text(root,'02_AI生成的Prompt/link.md')
    def test_initialization_and_parse_errors(self):
        out=rpc([req(1,'tools/list'),'not json']+init()+[req(5,'unknown/method')])
        self.assertIn('error',out[0]);self.assertEqual(out[1]['error']['code'],-32700);self.assertEqual(out[-1]['error']['code'],-32601)
    def test_config_generator_does_not_write(self):
        before=set(ROOT.rglob('*'))
        run=subprocess.run([sys.executable,str(ROOT/'06_教师与维护/工具脚本/生成MCP配置.py'),'--python','python3'],capture_output=True,text=True,encoding='utf-8',timeout=10)
        self.assertEqual(run.returncode,0);data=json.loads(run.stdout)['mcpServers']['product-website-kit'];self.assertEqual(data['command'],'python3');self.assertEqual(data['args'][-1],str(ROOT));self.assertEqual(before,set(ROOT.rglob('*')))

if __name__=='__main__':unittest.main(verbosity=2)
