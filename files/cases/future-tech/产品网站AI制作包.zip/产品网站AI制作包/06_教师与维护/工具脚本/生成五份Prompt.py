#!/usr/bin/env python3
"""Write five structured prompt DOCX files, then reread them. Standard library only."""
import argparse, copy, hashlib, json, os, re, shutil, sys, tempfile, uuid, zipfile
from datetime import datetime
from pathlib import Path
import xml.etree.ElementTree as ET

SOURCE_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(SOURCE_ROOT / "06_教师与维护/工具脚本"))
from 文档读取 import read_document

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML = "http://www.w3.org/XML/1998/namespace"
ET.register_namespace("w", W)
for prefix, uri in {
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcterms": "http://purl.org/dc/terms/",
    "xsi": "http://www.w3.org/2001/XMLSchema-instance"
}.items(): ET.register_namespace(prefix, uri)
def w(name): return "{" + W + "}" + name
DIMENSIONS = json.loads((SOURCE_ROOT / "Skills/website-b0-intake/五份Prompt字段.json").read_text(encoding="utf-8"))

def nonempty(value, label):
    if not isinstance(value, str) or not value.strip() or value.strip() in {"待填写", "待AI生成", "____", "TODO"}:
        raise ValueError(label + " must contain actual content")
    if any(ord(c) < 32 and c not in "\n\r\t" for c in value):
        raise ValueError(label + " contains invalid Word control characters")
    return value

def validate(data):
    if not isinstance(data, dict): raise ValueError("Input must be an object")
    for key in ("project", "version", "source"): nonempty(data.get(key), key)
    docs = data.get("documents")
    if not isinstance(docs, list) or len(docs) != 5: raise ValueError("Exactly five documents are required")
    by_id = {}
    for doc in docs:
        if not isinstance(doc, dict) or doc.get("id") in by_id: raise ValueError("Duplicate or invalid document")
        by_id[doc.get("id")] = doc
    if set(by_id) != {d["id"] for d in DIMENSIONS}: raise ValueError("Document ids must be 01 through 05")
    for dim in DIMENSIONS:
        doc = by_id[dim["id"]]
        nonempty(doc.get("idea"), dim["id"] + ".idea")
        prompt = doc.get("prompt")
        if not isinstance(prompt, dict) or set(prompt) != set(dim["fields"]):
            raise ValueError(dim["id"] + " has missing or unexpected prompt fields")
        for field in dim["fields"]: nonempty(prompt[field], dim["id"] + "." + field)
        notes = doc.get("notes", [])
        if not isinstance(notes, list): raise ValueError("notes must be a list")
        for note in notes: nonempty(note, "note")
    return by_id

def paragraph(text, style=None):
    p = ET.Element(w("p"))
    pr = ET.SubElement(p, w("pPr"))
    if style:
        ET.SubElement(pr, w("pStyle"), {w("val"): style})
        ET.SubElement(pr, w("keepNext"))
    ET.SubElement(pr, w("spacing"), {w("before"): "100" if style else "0", w("after"): "80", w("line"): "340", w("lineRule"): "exact"})
    ET.SubElement(pr, w("snapToGrid"), {w("val"): "0"})
    r = ET.SubElement(p, w("r"))
    rp = ET.SubElement(r, w("rPr"))
    ET.SubElement(rp, w("rFonts"), {w("ascii"): "Times New Roman", w("hAnsi"): "Times New Roman", w("eastAsia"): "Songti SC", w("cs"): "Times New Roman"})
    ET.SubElement(rp, w("sz"), {w("val"): "24"})
    ET.SubElement(rp, w("color"), {w("val"): "000000"})
    ET.SubElement(rp, w("b"), {w("val"): "1" if style else "0"})
    ET.SubElement(r, w("t"), {"{" + XML + "}space": "preserve"}).text = text
    return p

def render_one(template, output, data, dim, item):
    with zipfile.ZipFile(template) as z:
        parts = {info.filename: z.read(info.filename) for info in z.infolist()}
    tree = ET.fromstring(parts["word/document.xml"])
    tree.attrib.pop("{http://schemas.openxmlformats.org/markup-compatibility/2006}Ignorable", None)
    body = tree.find(w("body"))
    sect = body.find(w("sectPr"))
    sect = copy.deepcopy(sect) if sect is not None else None
    for child in list(body): body.remove(child)
    def add(text, style=None):
        for line in text.splitlines() or [""]: body.append(paragraph(line, style))
    add(dim["title"] + "结构化Prompt", "Title")
    add("项目：" + data["project"] + "　版本：" + data["version"])
    add("来源：" + data["source"])
    add("状态：已整理并保存；未知与假设按正文处理。")
    add("一 我的想法", "Heading1")
    add(item["idea"])
    add("二 AI整理的结构化Prompt", "Heading1")
    for field in dim["fields"]:
        add(field, "Heading2")
        add(item["prompt"][field])
    add("三 处理说明与后续修改", "Heading1")
    for note in item.get("notes", []) or ["后续在聊天中补充本角度的想法，由AI更新这一组Word并重新读取。"]:
        add(note)
    if sect is not None: body.append(sect)
    parts["word/document.xml"] = ET.tostring(tree, encoding="utf-8", xml_declaration=True)
    if "docProps/core.xml" in parts:
        core = ET.fromstring(parts["docProps/core.xml"])
        ns = {"dc": "http://purl.org/dc/elements/1.1/"}
        title = core.find("dc:title", ns)
        if title is not None: title.text = dim["title"] + "结构化Prompt"
        parts["docProps/core.xml"] = ET.tostring(core, encoding="utf-8", xml_declaration=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as z:
        for name, content in parts.items(): z.writestr(name, content)

def check_readback(path, data, dim, item):
    content = read_document(path)
    expected = [data["project"], data["version"], item["idea"], *item["prompt"].values(), *item.get("notes", [])]
    for value in expected:
        for line in value.splitlines():
            if line.strip() and line.strip() not in content:
                raise ValueError("Word readback lost content: " + dim["id"])
    return content

def generate(data, root):
    by_id = validate(data)
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    for folder in ("02_AI生成的Prompt", "03_AI生成的网站"): (root / folder).mkdir(exist_ok=True)
    receipt_path = root / "03_AI生成的网站/05_Prompt版本记录/生成与回读记录.json"
    payload_path = root / "03_AI生成的网站/05_Prompt版本记录/结构化内容.json"
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    history = None
    with tempfile.TemporaryDirectory(prefix="prompt-write-", dir=root) as tmp:
        tmp = Path(tmp)
        prepared = []
        for dim in DIMENSIONS:
            template = SOURCE_ROOT / "02_AI生成的Prompt" / dim["filename"]
            dest = root / "02_AI生成的Prompt" / dim["filename"]
            candidate = tmp / dim["filename"]
            render_one(template, candidate, data, dim, by_id[dim["id"]])
            check_readback(candidate, data, dim, by_id[dim["id"]])
            prepared.append((dim, candidate, dest))
        targets = [dest for _, _, dest in prepared] + [receipt_path, payload_path]
        prior = {path: path.read_bytes() for path in targets if path.exists()}
        if prior:
            history = root / "03_AI生成的网站/05_Prompt版本记录/历史版本" / (datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6])
            for path, content in prior.items():
                backup = history / path.relative_to(root)
                backup.parent.mkdir(parents=True, exist_ok=True)
                backup.write_bytes(content)
        try:
            for _, candidate, dest in prepared: os.replace(candidate, dest)
            records = []
            for dim, _, dest in prepared:
                text = check_readback(dest, data, dim, by_id[dim["id"]])
                records.append({"id": dim["id"], "path": str(dest.relative_to(root)), "version": data["version"], "sha256": hashlib.sha256(dest.read_bytes()).hexdigest(), "reread_characters": len(text)})
            receipt = {"project": data["project"], "version": data["version"], "status": "written_and_reread", "documents": records, "history": str(history.relative_to(root)) if history else None, "next": "Read these five Word files for B1-B8; this receipt does not certify website completion."}
            payload_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        except Exception:
            for target in targets:
                if target in prior: target.write_bytes(prior[target])
                elif target.exists(): target.unlink()
            raise
    return receipt

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="AI-completed structured content JSON")
    parser.add_argument("--root", type=Path, default=SOURCE_ROOT, help="Student project directory")
    args = parser.parse_args()
    try:
        result = generate(json.loads(args.input.read_text(encoding="utf-8")), args.root)
    except (ValueError, OSError, zipfile.BadZipFile, ET.ParseError) as exc:
        parser.exit(1, str(exc) + "\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))

