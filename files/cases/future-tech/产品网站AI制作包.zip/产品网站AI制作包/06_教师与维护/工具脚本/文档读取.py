#!/usr/bin/env python3
"""Read plain text and the text/table content of DOCX with the standard library."""
from pathlib import Path
import xml.etree.ElementTree as ET
from zipfile import ZipFile, BadZipFile

W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
R = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
REL = '{http://schemas.openxmlformats.org/package/2006/relationships}'
MAX_XML = 4_000_000

def read_document(path):
    path = Path(path)
    if path.suffix.lower() != '.docx':
        return path.read_text(encoding='utf-8')
    try:
        with ZipFile(path) as z:
            info = z.getinfo('word/document.xml')
            if info.file_size > MAX_XML:
                raise ValueError('Word document text exceeds the teaching-tool limit')
            root = ET.fromstring(z.read(info))
            rels = {}
            if 'word/_rels/document.xml.rels' in z.namelist():
                ri = z.getinfo('word/_rels/document.xml.rels')
                if ri.file_size > MAX_XML: raise ValueError('Word relationships are too large')
                for x in ET.fromstring(z.read(ri)):
                    if x.get('Type', '').endswith('/hyperlink'):
                        rels[x.get('Id')] = x.get('Target', '')
    except (BadZipFile, KeyError, ET.ParseError) as e:
        raise ValueError('Cannot read this Word document') from e
    def plain(node):
        out=[]
        for x in node.iter():
            if x.tag == W+'t': out.append(x.text or '')
            elif x.tag in (W+'br', W+'cr'): out.append('\n')
            elif x.tag == W+'tab': out.append('\t')
        return ''.join(out)
    def paragraph(p, headings=True):
        chunks=[]
        for x in p:
            if x.tag == W+'hyperlink':
                label=plain(x); target=rels.get(x.get(R+'id'), '')
                chunks.append('['+label+']('+target+')' if target else label)
            else: chunks.append(plain(x))
        text=''.join(chunks)
        style=p.find('./'+W+'pPr/'+W+'pStyle')
        sid=style.get(W+'val', '') if style is not None else ''
        if headings and sid in ('Title','Heading1','Heading2','Heading3'):
            text={'Title':'# ','Heading1':'## ','Heading2':'### ','Heading3':'#### '}[sid]+text
        return text
    lines=[]
    body=root.find(W+'body')
    if body is None: raise ValueError('Word document body is missing')
    for node in body:
        if node.tag == W+'p':
            text=paragraph(node)
            if text.strip(): lines.append(text)
        elif node.tag == W+'tbl':
            rows=[]
            for tr in node.findall(W+'tr'):
                cells=[]
                for tc in tr.findall(W+'tc'):
                    text=' / '.join(paragraph(p,False) for p in tc.findall(W+'p'))
                    cells.append(text.replace('|','｜').replace('\n',' / '))
                rows.append(cells)
            for i,row in enumerate(rows):
                lines.append('| '+' | '.join(row)+' |')
                if i==0: lines.append('| '+' | '.join('---' for _ in row)+' |')
        lines.append('')
    return '\n'.join(lines).strip()+'\n'

