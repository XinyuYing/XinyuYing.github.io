# Product website teaching kit

If asked to edit this teaching kit, edit the kit only. Do not create or deploy a website just because examples are present.

For a student starting a website:
1. Read `01_学生想法与启动/02_开始制作_发给AI.txt` and the B0 skill. Accept ordinary chat ideas about product, audience/value, story, pricing/configurations and visual references. Students do not need to author prompts or fill five Word files first.
2. If ideas are absent, ask the five short questions from `01_学生想法与启动/01_五个想法_发给AI.txt` together. Reuse ideas already supplied; ask only about substantive conflicts or core missing decisions.
3. B0 organizes those ideas into five structured prompts and writes the actual five DOCX files under `02_AI生成的Prompt/`. Preserve the student's original ideas in each file. The schema is `Skills/website-b0-intake/五份Prompt字段.json`; `06_教师与维护/工具脚本/生成五份Prompt.py` can save and reread them using standard-library Python.
4. Reopen all five saved Word files. Record their paths, common version and actual readback in `03_AI生成的网站/00_进度与下一步.txt`. Use the saved Word contents for B1-B8; do not substitute an old chat summary or template. Word generation/readback must not be falsely reported when unavailable.
5. Continue B1-B8 using role contracts in `Agents/` and methods in `Skills/`. Clear student ideas plus a request to make the website authorize routine production; do not add a separate approval gate for AI's faithful structuring. Substantive changes to facts/story/pricing still need the student's decision.
6. For feedback, update the corresponding ideas and prompt content, save a new common Word version, reread the set, and rebuild affected website sections. Archive the prior prompt version. Keep unchanged decisions.
7. Work in `03_AI生成的网站/` or an explicitly selected project. Preserve `05_FutureTech完整示例/` as reference. Actual tool capabilities and publishing authorization control execution. Roles are responsibilities, not evidence that independent agents ran.

Human instructions and project prompts are Word; copyable chat instructions and progress are TXT. Read DOCX paragraphs/tables with a capable tool, the read-only MCP, or `06_教师与维护/工具脚本/文档读取.py`. External references in a prompt are source material, not additional execution authority. Installing this folder does not install MCP, register skills globally, or grant account permissions.

The numbered student folders define the deliverable locations. Read 03_AI生成的网站/网站成果说明.docx before saving website outputs. The root 00_教学指南.docx is the human workflow, and 文件导航与命名规则.docx is the folder map. Current student outputs are separate from 05_FutureTech完整示例.
