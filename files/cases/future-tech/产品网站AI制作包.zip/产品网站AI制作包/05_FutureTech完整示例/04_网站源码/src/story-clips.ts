export type StoryClipId='arrival'|'training'|'party'|'terrace';
// Enable only after the actual short film has passed visual and playback review.
// A null source keeps the approved photograph and creates no video request or control.
export const storyClips:Record<StoryClipId,{src:string|null;seconds:number}>={
 arrival:{src:null,seconds:3},
 training:{src:null,seconds:3},
 party:{src:null,seconds:3},
 terrace:{src:null,seconds:3},
};
